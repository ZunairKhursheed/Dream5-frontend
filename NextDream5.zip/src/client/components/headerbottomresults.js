import React from "react";
// import style from "@/styles/pages/results.scss"









export const HeaderBottomResults = () => {
  return (
    <div className="header_bottom hbResult container p-0 d-flex">
      <div className="col header_tab_new d-flex justify-content-center align-items-center">
        Contests
      </div>
      <div className="col header_tab_new d-flex justify-content-center align-items-center">
        MY contests
      </div>
      <div className="col header_tab_new d-flex active justify-content-center align-items-center">
       my Picks
      </div>
  </div>
    
    




    

  );
};