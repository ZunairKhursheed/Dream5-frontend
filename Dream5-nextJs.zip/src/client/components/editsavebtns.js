import React from "react";
import style from "@/styles/pages/reviewSelection.scss"









export const EditSaveBtns = () => {
  return (
    
  
    <div className="previous-next d-flex justify-content-center p-4">
    <div className="btn btn-edit">EDIT</div>
    <div className="btn btn-save">SAVE</div>
  </div>



    

  );
};