import React from "react";
import style from "@/styles/pages/results.scss"









export const Pickbtn = () => {
  return (
    
    
    <div className="pick-btn-container d-flex justify-content-center">
      <div className="btn-make-your-picks text-center my-2">
        MAKE YOUR PICKS
      </div>
    </div>




    

  );
};