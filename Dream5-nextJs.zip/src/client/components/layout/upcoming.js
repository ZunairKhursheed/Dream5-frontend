import React from "react";

import style from "@/styles/pages/home.module.scss"


export const Upcoming = () => {
  return (

    <div className="container mt-3">
    <h4 className={style.upcoming_heading}>Upcoming Match</h4>
  </div>



    
  
  );
};